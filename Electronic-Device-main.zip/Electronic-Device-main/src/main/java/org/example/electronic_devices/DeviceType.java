package org.example.electronic_devices;

public enum DeviceType {
    SMARTPHONE, LAPTOP, TABLET;
}
